package com.example.flutter_bloc_concepts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
