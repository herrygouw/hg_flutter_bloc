enum ConnectionType {
  Wifi,
  Mobile,
}
